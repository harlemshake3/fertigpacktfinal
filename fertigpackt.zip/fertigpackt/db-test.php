<?php
require_once 'system/config.php';
echo "Verbindung erfolgreich!";
?>
