<?php
$host = '4c48df.myd.infomaniak.com';
$db   = '4c48df_goGina';
$user = '4c48df_harunlol';
$pass = 'Lucatim1.';

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    echo "Datenbankverbindung fehlgeschlagen: " . $e->getMessage();
    exit;
}
?>
